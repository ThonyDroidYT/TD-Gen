#include
int main()
{
printf("Bienvenidos a mis repositorios les estare dejando una recopilacion de los mejores ADM ya desencriptados");
return 0;
}
