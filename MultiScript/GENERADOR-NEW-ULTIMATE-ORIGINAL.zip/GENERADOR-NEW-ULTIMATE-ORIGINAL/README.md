﻿# GENERADOR-NEW-ULTIMATE-ORIGINAL

# ESTE PROYECTO A SIDO DESCONTINUADO.--

```
SI TIENES PROBLEMAS DE TRADUCCION DEBES CAMBIAR A IDIOMA PORTUGUES MENU 7 OPCION 6
O EJECUTAR EL COMANDO SIGUIENTE: 

                echo "pt" > /etc/newadm/idioma && chmod +x /etc/newadm/idioma
```

-------------------------------------------------------------------------------

**Generador De Key NEWADM**

## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu o Debian)
* Recomendamos Ubuntu 14.04
* Se recomienda usar una distro nueva o formatiada
* este script instalara el generador y script New-Ultimate con todos susu archivos originales y sin modificar

## Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/master/GENERADOR-NEW-ULTIMATE-ORIGINAL/instgerador.sh; chmod 777 instgerador.sh* && ./instgerador.sh

-------------------------------------------------------------------------------

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/GENERADOR-NEW-ULTIMATE-ORIGINAL/Imagenes/INSTALL_GENERADOR.png)

```
PARA INGRESAR AL GENERADOR ESCRIBE LOS COMANDOS EN MINUSCULA  gerar.sh o gerar
```

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/GENERADOR-NEW-ULTIMATE-ORIGINAL/Imagenes/GENERADOR_NEW_ULTIMATE.png)


```
NEW - ADM - MANAGER ( OFICIAL ) PARA QUE USEN SU GENERADOR DE KEY
```

## Installation

apt-get update -y; apt-get upgrade -y; wget https://www.dropbox.com/s/s4k7ovuimvkr3zf/instalar.sh?dl=0; chmod 777 instalar.sh* && ./instalar.sh*

-------------------------------------------------------------------------------

```
INSTALADOR ALTERNATIVO
```

## Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/master/GENERADOR-NEW-ULTIMATE-ORIGINAL/instalar.sh; chmod 777 instalar.sh* && ./instalar.sh*

-------------------------------------------------------------------------------

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/GENERADOR-NEW-ULTIMATE-ORIGINAL/Imagenes/INSTALL_NEWADM.png)

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/GENERADOR-NEW-ULTIMATE-ORIGINAL/Imagenes/NEW_ULTIMATE.png)

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆

```

**By: [  ⃘⃤꙰✰ ]**