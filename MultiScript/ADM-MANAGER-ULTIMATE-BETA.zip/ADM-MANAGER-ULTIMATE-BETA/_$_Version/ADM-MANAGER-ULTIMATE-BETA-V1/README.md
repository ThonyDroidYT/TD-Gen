﻿# ADM-MANAGER-ULTIMATE-BETA

Manager Script

1 • RECOMENDADO UBUNTU 14.04

2 • USAR DISTRIBUCION NUEVA O FORMATIADA

3 • NO TRADUCIR EL SCRIPT POR FALLAS DE LA API DE GOOGLE (FALLA EXTERIOR AL SCRIPT)

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/ADM-MANAGER-ULTIMATE-BETA/master/instalarold.sh; chmod +x instalarold.sh; ./instalarold.sh

==================================================================================

*SIN MINERIA! *SIN KEYS! *VERSION GRATUITA *SIN VIRUS TROJANO (BOTNET) *ARCHIVOS LIBERADOS (DECENCRIPTADOS)

==================================================================================

☆ https://t.me/admmanagerfree ☆
=================================================
TEAM [ ILLUMINATI ⃘⃤꙰✰ ] @El_Gato

[ FULL SCRIPTS ⃘⃤꙰✰ ] && VPS