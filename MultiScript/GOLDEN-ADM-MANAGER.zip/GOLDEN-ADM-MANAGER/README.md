# GOLDEN-ADM-MANAGER

# (NO RECOMENDADO - SOLO USAR PARA TESTEOS )

**Manager Script Repositorio**

* Un sistema operativo basado en Linux. Recomendamos Ubuntu 14.04
* Se recomienda usar una distro nueva o formatiada.

## Installation

apt-get update && apt-get upgrade -y: wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/master/GOLDEN-ADM-MANAGER/goldenvps.sh; chmod 777 goldenvps.sh* && ./goldenvps.sh.sh*
