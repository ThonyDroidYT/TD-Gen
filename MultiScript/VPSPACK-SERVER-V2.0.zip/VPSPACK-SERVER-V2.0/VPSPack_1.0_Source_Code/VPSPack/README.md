# vpspack
# Install
wget https://raw.githubusercontent.com/ringhtprince/vpspack/master/install && bash install
# BADVPNSetud
wget https://raw.githubusercontent.com/ringhtprince/Scripts/master/badvpnsetup.sh && bash badvpnsetup.sh
# TCPtweaker
wget https://raw.githubusercontent.com/ringhtprince/Scripts/master/tcptweaker.sh && bash tcptweaker.sh

Hecho Por RinghtPrince y MagodOz
