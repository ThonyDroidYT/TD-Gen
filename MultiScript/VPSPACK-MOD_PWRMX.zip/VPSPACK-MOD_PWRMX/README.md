# VPSPACK MOD @PWRMX

# (NO RECOMENDADO - SOLO USAR PARA TESTEOS )

**Manager Script Repositorio**

* Un sistema operativo basado en Linux (Ubuntu o Debian) 
* Recomendamos Ubuntu 16.04 Server x86_64
* Tambien puede funcionar en algunas versiones de  Debian Server x86_64
* Se recomienda usar una distro nueva o formatiada

## Installation

apt-get update -y; apt-get upgrade -y; wget https://www.dropbox.com/s/s6ybopqsz3wq4fx/instalador; chmod 777 instalador* && ./instalador*

* Creditos: https://github.com/casitadelterror

