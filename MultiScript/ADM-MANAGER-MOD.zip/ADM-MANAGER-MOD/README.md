﻿# ADM-MANAGER-MOD

# ESTE PROYECTO A SIDO DESCONTINUADO.--

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/blob/master/ADM-MANAGER-MOD/Imagenes/ADM_MANAGER_MOD.jpg)

-------------------------------------------------------------------------------

**Manager Script**

## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu o Debian)
* Recomendamos Ubuntu 14.04
* Se recomienda usar una distro nueva o formatiada

## Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/PROYECTOS_DESCONTINUADOS/master/ADM-MANAGER-MOD/instala.sh; chmod +x instala.sh; ./instala.sh

-------------------------------------------------------------------------------

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆

```

**By: [  ⃘⃤꙰✰ ]**